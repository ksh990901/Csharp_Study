# class Myclass :
#     def __init__(self,*num):
#         self.lists = list(num)
# mylists = Myclass(10,20,30,40,50)
# print(mylists.lists)

class Myclass:
    def __init__(self, *num):
        self.lists = list(num)
    
    def __iter__(self):
        self.index = 0
        return self

    def __next__(self):
        if self.index < len(self.lists):
            result = self.lists[self.index]
            self.index += 1
            return result
        else:
            raise StopIteration

mylists = Myclass(10, 20, 30, 40, 50)

for item in mylists:
    print(item)

# print("F : {1},S : {2} , T : {0}".format("참","나","원"))

# print("아아아" * 5)
